<?php

return ['commaSequence', 'variable', 'string', 'color', 'metric', 'other', 'function'];