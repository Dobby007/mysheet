<?php

return [
    'white' => 'ffffff',
    'silver' => 'c0c0c0',
    'gray' => '808080',
    'black' => '000000',
    'maroon' => '800000',
    'red' => 'ff0000',
    'orange' => 'ffa500',
    'yellow' => 'ffff00',
    'olive' => '808000',
    'lime' => '00ff00',
    'green' => '008000',
    'aqua' => '00ffff',
    'blue' => '0000ff',
    'navy' => '000080',
    'teal' => '008080',
    'fuchsia' => 'ff00ff',
    'purple' => '800080'
];