<?php

return ['mathExpr', 'sequence', 'variable', 'string', 'color', 'metric', 'nonQuotedString', 'function'];