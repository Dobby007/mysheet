<?php

return [
    ['unaryPlus', 'unaryMinus'], ['multiply', 'divide'], ['plus', 'minus']
];