<?php

return [
    'plus', 'minus', 'multiply', 'divide', 'unaryPlus', 'unaryMinus'
];